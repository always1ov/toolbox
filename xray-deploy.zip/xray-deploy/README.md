# Xray VLESS + Reality Windows 一键部署包

**适用环境：Windows VPS（Windows Server 2016/2019/2022）**

---

## 包含文件

| 文件 | 说明 |
|------|------|
| `xray-deploy-final.ps1` | 一键部署脚本 |
| `README.md` | 本说明文档 |

---

## 部署步骤

### 第一步：上传脚本到 VPS

通过 RDP 连接到 VPS，将 `xray-deploy-final.ps1` 复制到桌面或任意目录。

### 第二步：以管理员身份打开 PowerShell

右键开始菜单 → **Windows PowerShell（管理员）**

### 第三步：进入脚本所在目录

```powershell
# 如果放在桌面
cd C:\Users\Administrator\Desktop
```

### 第四步：允许脚本执行

```powershell
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
```

提示是否更改策略，输入 `A` 回车确认。

### 第五步：运行脚本

```powershell
.\xray-deploy-final.ps1
```

等待脚本自动完成，全程约 1-3 分钟。

---

## 脚本自动完成的事情

1. 检查 443 端口占用情况
2. 下载最新版 Xray-core
3. 下载 NSSM（Windows 服务管理工具）
4. 自动生成 UUID、Reality 密钥对、Short ID
5. 写入 `config.json`（无 BOM UTF-8，避免编码报错）
6. 配置 Windows 防火墙（开放 TCP 443）
7. 注册 Xray 为 Windows 服务（**开机自动启动**）
8. 启动服务并验证状态
9. 输出节点链接，保存到文件

---

## 部署完成后的文件位置

所有文件保存在 `C:\xray\`：

| 文件 | 内容 |
|------|------|
| `xray.exe` | Xray 主程序 |
| `config.json` | 配置文件 |
| `nssm.exe` | 服务管理工具 |
| `node-link.txt` | 节点链接（直接复制到客户端） |
| `node-info.txt` | 完整节点信息（含私钥，妥善保管） |
| `xray.log` | 运行日志 |

---

## 获取节点链接

脚本运行完成后，节点链接会直接显示在 PowerShell 窗口中（绿色文字）。

也可以随时查看：

```powershell
Get-Content C:\xray\node-link.txt
```

---

## 导入客户端

### Shadowrocket（iOS）

1. 复制节点链接
2. 打开 Shadowrocket → 右上角 **+**
3. 粘贴链接 → 自动填充 → 保存
4. 开启代理

### v2rayN（Windows/Android）

1. 复制节点链接
2. 从剪贴板导入

### 验证是否成功

开启代理后，用浏览器访问 `https://ip.sb`，显示 VPS 的 IP 地址即为成功。

---

## 服务管理命令

```powershell
# 查看服务状态
C:\xray\nssm.exe status xray

# 启动服务
C:\xray\nssm.exe start xray

# 停止服务
C:\xray\nssm.exe stop xray

# 重启服务
C:\xray\nssm.exe restart xray

# 查看最新日志
Get-Content C:\xray\xray.log -Tail 30
```

---

## 验证部署

```powershell
# 1. 确认服务运行中（应显示 SERVICE_RUNNING）
C:\xray\nssm.exe status xray

# 2. 确认日志无报错
Get-Content C:\xray\xray.log -Tail 10
```

日志正常输出：
```
Xray 26.x.x (Xray, Penetrates Everything.)
A unified platform for anti-censorship.
```

---

## IP 纯净度检测

开启代理后，用手机浏览器访问以下网站检测：

| 网站 | 检测内容 |
|------|------|
| https://ip.sb | 确认 IP 已切换到 VPS |
| https://dnsleaktest.com | DNS 泄露检测 |
| https://whoer.net | 综合匿名度评分 |
| https://blacklistchecker.com | IP 黑名单检测 |

---

## 常见问题

**Q：运行脚本提示"无法识别为 cmdlet"**
A：没有 cd 到脚本所在目录，先运行 `cd C:\Users\Administrator\Desktop`

**Q：服务状态是 SERVICE_PAUSED 无法启动**
A：config.json 有问题，查看日志：`Get-Content C:\xray\xray.log -Tail 20`

**Q：手机连不上**
A：检查 VPS 服务商控制台的安全组/防火墙，确认 TCP 443 入站已开放

**Q：VPS 重启后还能用吗**
A：可以，脚本已设置开机自启（SERVICE_AUTO_START），无需手动操作

**Q：如何在新机器重新部署**
A：直接运行 `xray-deploy-final.ps1`，脚本会自动清理旧配置重新部署

---

## 安全注意事项

- `node-info.txt` 包含私钥，**不要分享给他人**
- 节点链接也不要公开分享
- 定期检查 `xray.log` 确认无异常连接
