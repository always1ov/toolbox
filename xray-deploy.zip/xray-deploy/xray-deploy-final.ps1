# Xray VLESS + Reality - One-Click Deploy Script
# Run as Administrator in PowerShell
# Usage: .\xray-deploy-final.ps1

$ErrorActionPreference = "Continue"

function Info  { param($m) Write-Host "[INFO]  $m" -ForegroundColor Cyan }
function OK    { param($m) Write-Host "[OK]    $m" -ForegroundColor Green }
function Warn  { param($m) Write-Host "[WARN]  $m" -ForegroundColor Yellow }
function Fatal { param($m) Write-Host "[ERROR] $m" -ForegroundColor Red; Read-Host "Press Enter to exit"; exit 1 }

# ---- Check admin ----
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Fatal "Please run PowerShell as Administrator."
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Magenta
Write-Host "   Xray VLESS+Reality One-Click Deploy      " -ForegroundColor Magenta
Write-Host "============================================" -ForegroundColor Magenta
Write-Host ""

$InstallDir = "C:\xray"
$ConfigFile = "$InstallDir\config.json"
$XrayExe    = "$InstallDir\xray.exe"
$NssmExe    = "$InstallDir\nssm.exe"
$NodeInfo   = "$InstallDir\node-info.txt"
$LinkFile   = "$InstallDir\node-link.txt"
$LogFile    = "$InstallDir\xray.log"

# ---- Check port 443 ----
Info "Checking port 443..."
$portInUse = netstat -ano | findstr " :443 " | findstr "LISTENING"
if ($portInUse) {
    Warn "Port 443 is already being listened on by another process."
    Warn $portInUse
    $ans = Read-Host "Continue anyway? (y/N)"
    if ($ans -notmatch '^[Yy]$') { exit 0 }
} else {
    OK "Port 443 is available."
}

# ---- Create install dir ----
if (-not (Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Path $InstallDir | Out-Null
}
Info "Install dir: $InstallDir"

# ---- Download Xray ----
if (Test-Path $XrayExe) {
    OK "Xray already exists, skipping download."
} else {
    Info "Fetching latest Xray-core release..."
    try {
        $release = Invoke-RestMethod "https://api.github.com/repos/XTLS/Xray-core/releases/latest"
        $version = $release.tag_name
        $asset   = $release.assets | Where-Object { $_.name -eq "Xray-windows-64.zip" }
        $zipUrl  = $asset.browser_download_url
    } catch {
        Fatal "Cannot reach GitHub API. Check network and try again."
    }
    $zipPath = "$InstallDir\xray.zip"
    Info "Downloading Xray $version ..."
    try {
        Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing
    } catch {
        Fatal "Download failed. Check network and try again."
    }
    Expand-Archive -Path $zipPath -DestinationPath $InstallDir -Force
    Remove-Item $zipPath -Force
    OK "Xray downloaded."
}

# ---- Download NSSM ----
if (Test-Path $NssmExe) {
    OK "NSSM already exists, skipping download."
} else {
    Info "Downloading NSSM..."
    $nssmUrl = "https://nssm.cc/ci/nssm-2.24-101-g897c7ad.zip"
    $nssmZip = "$InstallDir\nssm.zip"
    $nssmTmp = "$InstallDir\nssm_tmp"
    try {
        Invoke-WebRequest -Uri $nssmUrl -OutFile $nssmZip -UseBasicParsing
        Expand-Archive -Path $nssmZip -DestinationPath $nssmTmp -Force
        $nssmBin = Get-ChildItem -Path $nssmTmp -Recurse -Filter "nssm.exe" |
                   Where-Object { $_.FullName -like "*win64*" } |
                   Select-Object -First 1
        if (-not $nssmBin) { throw "nssm.exe not found in archive" }
        Copy-Item $nssmBin.FullName $NssmExe -Force
        Remove-Item $nssmZip, $nssmTmp -Recurse -Force
        OK "NSSM downloaded."
    } catch {
        Fatal "NSSM download failed: $_"
    }
}

# ---- Generate UUID ----
Info "Generating UUID..."
$uuid = (& $XrayExe uuid 2>&1).Trim()
if (-not $uuid -or $uuid -notmatch '^[0-9a-f-]{36}$') {
    Fatal "UUID generation failed. Output: $uuid"
}
OK "UUID: $uuid"

# ---- Generate Reality keypair ----
Info "Generating Reality keypair..."
$keysRaw    = (& $XrayExe x25519 2>&1) -join " "
$privateKey = ""
$publicKey  = ""

# Format A: "Private key: xxx  Public key: xxx"
if ($keysRaw -match "Private key:\s*(\S+)") { $privateKey = $Matches[1].Trim() }
if ($keysRaw -match "Public key:\s*(\S+)")  { $publicKey  = $Matches[1].Trim() }

# Format B: "PrivateKey: xxx  Password (PublicKey): xxx"
if (-not $privateKey -and $keysRaw -match "PrivateKey:\s*(\S+)")              { $privateKey = $Matches[1].Trim() }
if (-not $publicKey  -and $keysRaw -match "Password \(PublicKey\):\s*(\S+)")  { $publicKey  = $Matches[1].Trim() }

if (-not $privateKey -or -not $publicKey) {
    Fatal "Failed to parse keypair. Raw output: $keysRaw"
}
OK "Private key: $privateKey"
OK "Public key:  $publicKey"

# ---- Generate Short ID ----
Info "Generating Short ID..."
$shortId = -join ((48..57) + (97..102) | Get-Random -Count 8 | ForEach-Object { [char]$_ })
OK "Short ID: $shortId"

# ---- Write config.json (no BOM) ----
Info "Writing config.json..."
$configJson = @"
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "port": 443,
      "protocol": "vless",
      "settings": {
        "clients": [ { "id": "$uuid", "flow": "xtls-rprx-vision" } ],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "tcp",
        "security": "reality",
        "realitySettings": {
          "show": false,
          "dest": "www.icloud.com:443",
          "serverNames": ["www.icloud.com"],
          "privateKey": "$privateKey",
          "shortIds": ["$shortId"]
        }
      }
    }
  ],
  "outbounds": [ { "protocol": "freedom", "tag": "direct" } ]
}
"@
$utf8NoBom = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText($ConfigFile, $configJson, $utf8NoBom)
OK "Config written: $ConfigFile"

# ---- Verify config is valid JSON ----
Info "Verifying config.json..."
try {
    $testRead = [System.IO.File]::ReadAllText($ConfigFile)
    $null = $testRead | ConvertFrom-Json
    OK "Config JSON is valid."
} catch {
    Fatal "Config JSON validation failed: $_"
}

# ---- Firewall ----
Info "Configuring firewall..."
$existingRule = Get-NetFirewallRule -DisplayName "Xray-443" -ErrorAction SilentlyContinue
if ($existingRule) { Remove-NetFirewallRule -DisplayName "Xray-443" -ErrorAction SilentlyContinue }
New-NetFirewallRule -DisplayName "Xray-443" -Direction Inbound `
    -Protocol TCP -LocalPort 443 -Action Allow | Out-Null
OK "Firewall rule added (TCP 443 inbound)."

# ---- Stop and remove old service ----
Info "Cleaning up old Xray service..."
$svcExists = (sc.exe query xray 2>&1) -notmatch "does not exist"
if ($svcExists) {
    sc.exe stop xray 2>&1 | Out-Null
    Start-Sleep -Seconds 2
    & $NssmExe remove xray confirm 2>&1 | Out-Null
    Start-Sleep -Seconds 1
    OK "Old service removed."
}

# Kill leftover xray.exe processes
Get-Process -Name "xray" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1

# ---- Register and start service ----
Info "Registering Xray as Windows service..."
& $NssmExe install xray $XrayExe "run -c `"$ConfigFile`"" | Out-Null
& $NssmExe set xray AppDirectory $InstallDir | Out-Null
& $NssmExe set xray Start SERVICE_AUTO_START | Out-Null
& $NssmExe set xray AppStdout $LogFile | Out-Null
& $NssmExe set xray AppStderr $LogFile | Out-Null
& $NssmExe set xray AppRotateFiles 1 | Out-Null

Info "Starting Xray service..."
& $NssmExe start xray | Out-Null
Start-Sleep -Seconds 3

$status = (& $NssmExe status xray).Trim()
if ($status -eq "SERVICE_RUNNING") {
    OK "Xray service is RUNNING."
} else {
    Warn "Service status: $status"
    Warn "Checking log..."
    if (Test-Path $LogFile) {
        Get-Content $LogFile -Tail 5 | ForEach-Object { Warn $_ }
    }
    Fatal "Xray failed to start. See log above."
}

# ---- Get public IP ----
Info "Getting public IP..."
$serverIp = "YOUR_VPS_IP"
try {
    $serverIp = (Invoke-RestMethod "https://api.ipify.org" -TimeoutSec 5).Trim()
    OK "Server IP: $serverIp"
} catch {
    Warn "Could not detect public IP. Please replace YOUR_VPS_IP in the node link manually."
}

# ---- Build node link ----
$nodeLink = "vless://${uuid}@${serverIp}:443?encryption=none&flow=xtls-rprx-vision&security=reality&sni=www.icloud.com&fp=chrome&pbk=${publicKey}&sid=${shortId}&type=tcp#MyNode"

# ---- Save node info ----
$infoText  = "Deploy time : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`r`n"
$infoText += "Server IP   : $serverIp`r`n"
$infoText += "Port        : 443`r`n"
$infoText += "UUID        : $uuid`r`n"
$infoText += "Public Key  : $publicKey`r`n"
$infoText += "Private Key : $privateKey`r`n"
$infoText += "Short ID    : $shortId`r`n"
$infoText += "`r`nNode Link:`r`n$nodeLink`r`n"
[System.IO.File]::WriteAllText($NodeInfo, $infoText, $utf8NoBom)
[System.IO.File]::WriteAllText($LinkFile, $nodeLink, $utf8NoBom)

# ---- Done ----
Write-Host ""
Write-Host "============================================" -ForegroundColor Magenta
Write-Host "  DONE! Xray is running."                   -ForegroundColor Magenta
Write-Host "============================================" -ForegroundColor Magenta
Write-Host ""
Write-Host "Server IP  : $serverIp"  -ForegroundColor White
Write-Host "Port       : 443"         -ForegroundColor White
Write-Host "UUID       : $uuid"       -ForegroundColor White
Write-Host "Public Key : $publicKey"  -ForegroundColor White
Write-Host "Short ID   : $shortId"    -ForegroundColor White
Write-Host ""
Write-Host "Node Link:" -ForegroundColor Yellow
Write-Host $nodeLink    -ForegroundColor Green
Write-Host ""
Write-Host "Files saved to C:\xray\" -ForegroundColor Gray
Write-Host "  node-link.txt  : node link only"          -ForegroundColor Gray
Write-Host "  node-info.txt  : full details"            -ForegroundColor Gray
Write-Host "  xray.log       : service log"             -ForegroundColor Gray
Write-Host ""
Write-Host "Manage service:"                                    -ForegroundColor Gray
Write-Host "  Status  : C:\xray\nssm.exe status xray"          -ForegroundColor Gray
Write-Host "  Restart : C:\xray\nssm.exe restart xray"         -ForegroundColor Gray
Write-Host "  Stop    : C:\xray\nssm.exe stop xray"            -ForegroundColor Gray
Write-Host "  Log     : Get-Content C:\xray\xray.log -Tail 30" -ForegroundColor Gray
Write-Host "============================================" -ForegroundColor Magenta
Write-Host ""
